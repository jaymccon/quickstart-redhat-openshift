
ruamel.yaml
===========

``ruamel.yaml`` is a YAML 1.2 loader/dumper package for Python.

:version:       0.16.6
:updated:       2020-01-20
:documentation: http://yaml.readthedocs.io
:repository:    https://bitbucket.org/ruamel/yaml
:pypi:          https://pypi.org/project/ruamel.yaml/


Starting with version 0.15.0 the way YAML files are loaded and dumped
is changing. See the API doc for details.  Currently existing
functionality will throw a warning before being changed/removed.
**For production systems you should pin the version being used with
``ruamel.yaml<=0.15``**. There might be bug fixes in the 0.14 series,
but new functionality is likely only to be available via the new API.

If your package uses ``ruamel.yaml`` and is not listed on PyPI, drop
me an email, preferably with some information on how you use the
package (or a link to bitbucket/github) and I'll keep you informed
when the status of the API is stable enough to make the transition.

* `Overview <http://yaml.readthedocs.org/en/latest/overview.html>`_
* `Installing <http://yaml.readthedocs.org/en/latest/install.html>`_
* `Basic Usage <http://yaml.readthedocs.org/en/latest/basicuse.html>`_
* `Details <http://yaml.readthedocs.org/en/latest/detail.html>`_
* `Examples <http://yaml.readthedocs.org/en/latest/example.html>`_
* `API <http://yaml.readthedocs.org/en/latest/api.html>`_
* `Differences with PyYAML <http://yaml.readthedocs.org/en/latest/pyyaml.html>`_

.. image:: https://readthedocs.org/projects/yaml/badge/?version=stable
   :target: https://yaml.readthedocs.org/en/stable

.. image:: https://bestpractices.coreinfrastructure.org/projects/1128/badge
   :target: https://bestpractices.coreinfrastructure.org/projects/1128

.. image:: https://bitbucket.org/ruamel/yaml/raw/default/_doc/_static/license.svg
   :target: https://opensource.org/licenses/MIT

.. image:: https://bitbucket.org/ruamel/yaml/raw/default/_doc/_static/pypi.svg
   :target: https://pypi.org/project/ruamel.yaml/

.. image:: https://bitbucket.org/ruamel/oitnb/raw/default/_doc/_static/oitnb.svg
   :target: https://pypi.org/project/oitnb/

.. image:: http://www.mypy-lang.org/static/mypy_badge.svg
   :target: http://mypy-lang.org/

ChangeLog
=========

.. should insert NEXT: at the beginning of line for next key (with empty line)

0.16.6 (2020-01-20):
  - fix empty string mapping key roundtripping with preservation of quotes as `? ''`
    (reported via email by Tomer Aharoni).
  - fix incorrect state setting in class constructor (reported by `Douglas Raillard
    <https://bitbucket.org/%7Bcf052d92-a278-4339-9aa8-de41923bb556%7D/>`__)
  - adjust deprecation warning test for Hashable, as that no longer warns (reported
    by `Jason Montleon <https://bitbucket.org/%7B8f377d12-8d5b-4069-a662-00a2674fee4e%7D/>`__)

0.16.5 (2019-08-18):
  - allow for ``YAML(typ=['unsafe', 'pytypes'])``

0.16.4 (2019-08-16):
  - fix output of TAG directives with # (reported by `Thomas Smith
    <https://bitbucket.org/%7Bd4c57a72-f041-4843-8217-b4d48b6ece2f%7D/>`__)


0.16.3 (2019-08-15):
  - split construct_object
  - change stuff back to keep mypy happy
  - move setting of version based on YAML directive to scanner, allowing to
    check for file version during TAG directive scanning

0.16.2 (2019-08-15):
  - preserve YAML and TAG directives on roundtrip, correctly output #
    in URL for YAML 1.2 (both reported by `Thomas Smith
    <https://bitbucket.org/%7Bd4c57a72-f041-4843-8217-b4d48b6ece2f%7D/>`__)

0.16.1 (2019-08-08):
  - Force the use of new version of ruamel.yaml.clib (reported by `Alex Joz
    <https://bitbucket.org/%7B9af55900-2534-4212-976c-61339b6ffe14%7D/>`__)
  - Allow '#' in tag URI as these are allowed in YAML 1.2 (reported by
    `Thomas Smith
    <https://bitbucket.org/%7Bd4c57a72-f041-4843-8217-b4d48b6ece2f%7D/>`__)

0.16.0 (2019-07-25):
  - split of C source that generates .so file to ruamel.yaml.clib
  - duplicate keys are now an error when working with the old API as well

0.15.100 (2019-07-17):
  - fixing issue with dumping deep-copied data from commented YAML, by
    providing both the memo parameter to __deepcopy__, and by allowing
    startmarks to be compared on their content (reported by `Theofilos
    Petsios
    <https://bitbucket.org/%7Be550bc5d-403d-4fda-820b-bebbe71796d3%7D/>`__)

0.15.99 (2019-07-12):
  - add `py.typed` to distribution, based on a PR submitted by
    `Michael Crusoe
    <https://bitbucket.org/%7Bc9fbde69-e746-48f5-900d-34992b7860c8%7D/>`__
  - merge PR 40 (also by Michael Crusoe) to more accurately specify
    repository in the README (also reported in a misunderstood issue
    some time ago)

0.15.98 (2019-07-09):
  - regenerate ext/_ruamel_yaml.c with Cython version 0.29.12, needed
    for Python 3.8.0b2 (reported by `John Vandenberg
    <https://bitbucket.org/%7B6d4e8487-3c97-4dab-a060-088ec50c682c%7D/>`__)

0.15.97 (2019-06-06):
  - regenerate ext/_ruamel_yaml.c with Cython version 0.29.10, needed for
    Python 3.8.0b1
  - regenerate ext/_ruamel_yaml.c with Cython version 0.29.9, needed for
    Python 3.8.0a4 (reported by `Anthony Sottile
    <https://bitbucket.org/%7B569cc8ea-0d9e-41cb-94a4-19ea517324df%7D/>`__)

0.15.96 (2019-05-16):
  - fix failure to indent comments on round-trip anchored block style
    scalars in block sequence (reported by `William Kimball
    <https://bitbucket.org/%7Bba35ed20-4bb0-46f8-bb5d-c29871e86a22%7D/>`__)

0.15.95 (2019-05-16):
  - fix failure to round-trip anchored scalars in block sequence
    (reported by `William Kimball
    <https://bitbucket.org/%7Bba35ed20-4bb0-46f8-bb5d-c29871e86a22%7D/>`__)
  - wheel files for Python 3.4 no longer provided (`Python 3.4 EOL 2019-03-18
    <https://www.python.org/dev/peps/pep-0429/>`__)

0.15.94 (2019-04-23):
  - fix missing line-break after end-of-file comments not ending in
    line-break (reported by `Philip Thompson
    <https://bitbucket.org/%7Be42ba205-0876-4151-bcbe-ccaea5bd13ce%7D/>`__)

0.15.93 (2019-04-21):
  - fix failure to parse empty implicit flow mapping key
  - in YAML 1.1 plains scalars `y`, 'n', `Y`, and 'N' are now
    correctly recognised as booleans and such strings dumped quoted
    (reported by `Marcel Bollmann
    <https://bitbucket.org/%7Bd8850921-9145-4ad0-ac30-64c3bd9b036d%7D/>`__)

0.15.92 (2019-04-16):
  - fix failure to parse empty implicit block mapping key (reported by 
    `Nolan W <https://bitbucket.org/i2labs/>`__)

0.15.91 (2019-04-05):
  - allowing duplicate keys would not work for merge keys (reported by mamacdon on
    `StackOverflow <https://stackoverflow.com/questions/55540686/>`__ 

0.15.90 (2019-04-04):
  - fix issue with updating `CommentedMap` from list of tuples (reported by 
    `Peter Henry <https://bitbucket.org/mosbasik/>`__)

0.15.89 (2019-02-27):
  - fix for items with flow-mapping in block sequence output on single line
    (reported by `Zahari Dim <https://bitbucket.org/zahari_dim/>`__)
  - fix for safe dumping erroring in creation of representereror when dumping namedtuple
    (reported and solution by `Jaakko Kantojärvi <https://bitbucket.org/raphendyr/>`__)

0.15.88 (2019-02-12):
  - fix inclusing of python code from the subpackage data (containing extra tests,
    reported by `Florian Apolloner <https://bitbucket.org/apollo13/>`__)

0.15.87 (2019-01-22):
  - fix problem with empty lists and the code to reinsert merge keys (reported via email 
     by Zaloo)

0.15.86 (2019-01-16):
  - reinsert merge key in its old position (reported by grumbler on
    `StackOverflow <https://stackoverflow.com/a/54206512/1307905>`__)
  - fix for issue with non-ASCII anchor names (reported and fix
    provided by Dandaleon Flux via email)
  - fix for issue when parsing flow mapping value starting with colon (in pure Python only)
    (reported by `FichteFoll <https://bitbucket.org/FichteFoll/>`__)

0.15.85 (2019-01-08):
  - the types used by ``SafeConstructor`` for mappings and sequences can
    now by set by assigning to ``XXXConstructor.yaml_base_dict_type``
    (and ``..._list_type``), preventing the need to copy two methods
    with 50+ lines that had ``var = {}`` hardcoded.  (Implemented to
    help solve an feature request by `Anthony Sottile
    <https://bitbucket.org/asottile/>`__ in an easier way)

0.15.84 (2019-01-07):
  - fix for ``CommentedMap.copy()`` not returning ``CommentedMap``, let alone copying comments etc.
    (reported by `Anthony Sottile <https://bitbucket.org/asottile/>`__)

0.15.83 (2019-01-02):
  - fix for bug in roundtripping aliases used as key (reported via email by Zaloo)

0.15.82 (2018-12-28):
  - anchors and aliases on scalar int, float, string and bool are now preserved. Anchors
    do not need a referring alias for these (reported by 
    `Alex Harvey <https://bitbucket.org/alexharv074/>`__)
  - anchors no longer lost on tagged objects when roundtripping (reported by `Zaloo 
    <https://bitbucket.org/zaloo/>`__)

0.15.81 (2018-12-06):
  - fix issue dumping methods of metaclass derived classes (reported and fix provided
    by `Douglas Raillard <https://bitbucket.org/DouglasRaillard/>`__)

0.15.80 (2018-11-26):
  - fix issue emitting BEL character when round-tripping invalid folded input
    (reported by Isaac on `StackOverflow <https://stackoverflow.com/a/53471217/1307905>`__)

0.15.79 (2018-11-21):
  - fix issue with anchors nested deeper than alias (reported by gaFF on
    `StackOverflow <https://stackoverflow.com/a/53397781/1307905>`__)

0.15.78 (2018-11-15):
  - fix setup issue for 3.8 (reported by `Sidney Kuyateh 
    <https://bitbucket.org/autinerd/>`__)

0.15.77 (2018-11-09):
  - setting `yaml.sort_base_mapping_type_on_output = False`, will prevent
    explicit sorting by keys in the base representer of mappings. Roundtrip
    already did not do this. Usage only makes real sense for Python 3.6+
    (feature request by `Sebastian Gerber <https://bitbucket.org/spacemanspiff2007/>`__).
  - implement Python version check in YAML metadata in ``_test/test_z_data.py``

0.15.76 (2018-11-01):
  - fix issue with empty mapping and sequence loaded as flow-style
    (mapping reported by `Min RK <https://bitbucket.org/minrk/>`__, sequence
    by `Maged Ahmed <https://bitbucket.org/maged2/>`__)

0.15.75 (2018-10-27):
  - fix issue with single '?' scalar (reported by `Terrance 
    <https://bitbucket.org/OllieTerrance/>`__)
  - fix issue with duplicate merge keys (prompted by `answering 
    <https://stackoverflow.com/a/52852106/1307905>`__ a 
    `StackOverflow question <https://stackoverflow.com/q/52851168/1307905>`__
    by `math <https://stackoverflow.com/users/1355634/math>`__)

0.15.74 (2018-10-17):
  - fix dropping of comment on rt before sequence item that is sequence item
    (reported by `Thorsten Kampe <https://bitbucket.org/thorstenkampe/>`__)

0.15.73 (2018-10-16):
  - fix irregular output on pre-comment in sequence within sequence (reported
    by `Thorsten Kampe <https://bitbucket.org/thorstenkampe/>`__)
  - allow non-compact (i.e. next line) dumping sequence/mapping within sequence.

0.15.72 (2018-10-06):
  - fix regression on explicit 1.1 loading with the C based scanner/parser
    (reported by `Tomas Vavra <https://bitbucket.org/xtomik/>`__)

0.15.71 (2018-09-26):
  - some of the tests now live in YAML files in the 
    `yaml.data <https://bitbucket.org/ruamel/yaml.data>`__ repository. 
    ``_test/test_z_data.py`` processes these.
  - fix regression where handcrafted CommentedMaps could not be initiated (reported by 
    `Dan Helfman <https://bitbucket.org/dhelfman/>`__)
  - fix regression with non-root literal scalars that needed indent indicator
    (reported by `Clark Breyman <https://bitbucket.org/clarkbreyman/>`__)
  - tag:yaml.org,2002:python/object/apply now also uses __qualname__ on PY3
    (reported by `Douglas RAILLARD <https://bitbucket.org/DouglasRaillard/>`__)
  - issue with self-referring object creation
    (reported and fix by `Douglas RAILLARD <https://bitbucket.org/DouglasRaillard/>`__)

0.15.70 (2018-09-21):
  - reverted CommentedMap and CommentedSeq to subclass ordereddict resp. list,
    reimplemented merge maps so that both ``dict(**commented_map_instance)`` and JSON
    dumping works. This also allows checking with ``isinstance()`` on ``dict`` resp. ``list``.
    (Proposed by `Stuart Berg <https://bitbucket.org/stuarteberg/>`__, with feedback
    from `blhsing <https://stackoverflow.com/users/6890912/blhsing>`__ on
    `StackOverflow <https://stackoverflow.com/q/52314186/1307905>`__)

0.15.69 (2018-09-20):
  - fix issue with dump_all gobbling end-of-document comments on parsing
    (reported by `Pierre B. <https://bitbucket.org/octplane/>`__)

0.15.68 (2018-09-20):
  - fix issue with parsabel, but incorrect output with nested flow-style sequences
    (reported by `Dougal Seeley <https://bitbucket.org/dseeley/>`__)
  - fix issue with loading Python objects that have __setstate__ and recursion in parameters
    (reported by `Douglas RAILLARD <https://bitbucket.org/DouglasRaillard/>`__)

0.15.67 (2018-09-19):
  - fix issue with extra space inserted with non-root literal strings 
    (Issue reported and PR with fix provided by 
    `Naomi Seyfer <https://bitbucket.org/sixolet/>`__.)

0.15.66 (2018-09-07):
  - fix issue with fold indicating characters inserted in safe_load-ed folded strings
    (reported by `Maximilian Hils <https://bitbucket.org/mhils/>`__).

0.15.65 (2018-09-07):
  - fix issue #232 revert to throw ParserError for unexcpected ``]``
    and ``}`` instead of IndexError. (Issue reported and PR with fix
    provided by `Naomi Seyfer <https://bitbucket.org/sixolet/>`__.)
  - added ``key`` and ``reverse`` parameter (suggested by Jannik Klemm via email)
  - indent root level literal scalars that have directive or document end markers
    at the beginning of a line

0.15.64 (2018-08-30):
  - support round-trip of tagged sequences: ``!Arg [a, {b: 1}]``
  - single entry mappings in flow sequences now written by default without braces,
    set ``yaml.brace_single_entry_mapping_in_flow_sequence=True`` to force
    getting ``[a, {b: 1}, {c: {d: 2}}]`` instead of the default ``[a, b: 1, c: {d: 2}]``
  - fix issue when roundtripping floats starting with a dot such as ``.5``
    (reported by `Harrison Gregg <https://bitbucket.org/HarrisonGregg/>`__)

0.15.63 (2018-08-29):
  - small fix only necessary for Windows users that don't use wheels.

0.15.62 (2018-08-29):
  - C based reader/scanner & emitter now allow setting of 1.2 as YAML version.
    ** The loading/dumping is still YAML 1.1 code**, so use the common subset of
    YAML 1.2 and 1.1 (reported by `Ge Yang <https://bitbucket.org/yangge/>`__)

0.15.61 (2018-08-23):
  - support for round-tripping folded style scalars (initially requested 
    by `Johnathan Viduchinsky <https://bitbucket.org/johnathanvidu/>`__)
  - update of C code
  - speed up of scanning (~30% depending on the input)

0.15.60 (2018-08-18):
  - again allow single entry map in flow sequence context (reported by 
    `Lee Goolsbee <https://bitbucket.org/lgoolsbee/>`__)
  - cleanup for mypy 
  - spurious print in library (reported by 
    `Lele Gaifax <https://bitbucket.org/lele/>`__), now automatically checked 

0.15.59 (2018-08-17):
  - issue with C based loader and leading zeros (reported by 
    `Tom Hamilton Stubber <https://bitbucket.org/TomHamiltonStubber/>`__)

0.15.58 (2018-08-17):
  - simple mappings can now be used as keys when round-tripping::

      {a: 1, b: 2}: hello world

    although using the obvious operations (del, popitem) on the key will
    fail, you can mutilate it by going through its attributes. If you load the
    above YAML in `d`, then changing the value is cumbersome:

        d = {CommentedKeyMap([('a', 1), ('b', 2)]): "goodbye"}

    and changing the key even more so:

        d[CommentedKeyMap([('b', 1), ('a', 2)])] = d.pop(
                     CommentedKeyMap([('a', 1), ('b', 2)]))

    (you can use a `dict` instead of a list of tuples (or ordereddict), but that might result
    in a different order, of the keys of the key, in the output)
  - check integers to dump with 1.2 patterns instead of 1.1 (reported by 
    `Lele Gaifax <https://bitbucket.org/lele/>`__)


0.15.57 (2018-08-15):
  - Fix that CommentedSeq could no longer be used in adding or do a sort
    (reported by `Christopher Wright <https://bitbucket.org/CJ-Wright4242/>`__)

0.15.56 (2018-08-15):
  - fix issue with ``python -O`` optimizing away code (reported, and detailed cause
    pinpointed, by `Alex Grönholm <https://bitbucket.org/agronholm/>`__)

0.15.55 (2018-08-14):
  - unmade ``CommentedSeq`` a subclass of ``list``. It is now
    indirectly a subclass of the standard
    ``collections.abc.MutableSequence`` (without .abc if you are
    still on Python2.7). If you do ``isinstance(yaml.load('[1, 2]'),
    list)``) anywhere in your code replace ``list`` with
    ``MutableSequence``.  Directly, ``CommentedSeq`` is a subclass of
    the abstract baseclass ``ruamel.yaml.compat.MutableScliceableSequence``,
    with the result that *(extended) slicing is supported on 
    ``CommentedSeq``*.
    (reported by `Stuart Berg <https://bitbucket.org/stuarteberg/>`__)
  - duplicate keys (or their values) with non-ascii now correctly
    report in Python2, instead of raising a Unicode error.
    (Reported by `Jonathan Pyle <https://bitbucket.org/jonathan_pyle/>`__)

0.15.54 (2018-08-13):
  - fix issue where a comment could pop-up twice in the output (reported by 
    `Mike Kazantsev <https://bitbucket.org/mk_fg/>`__ and by 
    `Nate Peterson <https://bitbucket.org/ndpete21/>`__)
  - fix issue where JSON object (mapping) without spaces was not parsed
    properly (reported by `Marc Schmidt <https://bitbucket.org/marcj/>`__)
  - fix issue where comments after empty flow-style mappings were not emitted
    (reported by `Qinfench Chen <https://bitbucket.org/flyin5ish/>`__)

0.15.53 (2018-08-12):
  - fix issue with flow style mapping with comments gobbled newline (reported
    by `Christopher Lambert <https://bitbucket.org/XN137/>`__)
  - fix issue where single '+' under YAML 1.2 was interpreted as
    integer, erroring out (reported by `Jethro Yu
    <https://bitbucket.org/jcppkkk/>`__)

0.15.52 (2018-08-09):
  - added `.copy()` mapping representation for round-tripping
    (``CommentedMap``) to fix incomplete copies of merged mappings
    (reported by `Will Richards
    <https://bitbucket.org/will_richards/>`__) 
  - Also unmade that class a subclass of ordereddict to solve incorrect behaviour
    for ``{**merged-mapping}`` and ``dict(**merged-mapping)`` (reported independently by
    `Tim Olsson <https://bitbucket.org/tgolsson/>`__ and 
    `Filip Matzner <https://bitbucket.org/FloopCZ/>`__)

0.15.51 (2018-08-08):
  - Fix method name dumps (were not dotted) and loads (reported by `Douglas Raillard 
    <https://bitbucket.org/DouglasRaillard/>`__)
  - Fix spurious trailing white-space caused when the comment start
    column was no longer reached and there was no actual EOL comment
    (e.g. following empty line) and doing substitutions, or when
    quotes around scalars got dropped.  (reported by `Thomas Guillet
    <https://bitbucket.org/guillett/>`__)

0.15.50 (2018-08-05):
  - Allow ``YAML()`` as a context manager for output, thereby making it much easier
    to generate multi-documents in a stream. 
  - Fix issue with incorrect type information for `load()` and `dump()` (reported 
    by `Jimbo Jim <https://bitbucket.org/jimbo1qaz/>`__)

0.15.49 (2018-08-05):
  - fix preservation of leading newlines in root level literal style scalar,
    and preserve comment after literal style indicator (``|  # some comment``)
    Both needed for round-tripping multi-doc streams in 
    `ryd <https://pypi.org/project/ryd/>`__.

0.15.48 (2018-08-03):
  - housekeeping: ``oitnb`` for formatting, mypy 0.620 upgrade and conformity

0.15.47 (2018-07-31):
  - fix broken 3.6 manylinux1, the result of an unclean ``build`` (reported by 
    `Roman Sichnyi <https://bitbucket.org/rsichnyi-gl/>`__)


0.15.46 (2018-07-29):
  - fixed DeprecationWarning for importing from ``collections`` on 3.7
    (issue 210, reported by `Reinoud Elhorst
    <https://bitbucket.org/reinhrst/>`__). It was `difficult to find
    why tox/pytest did not report
    <https://stackoverflow.com/q/51573204/1307905>`__ and as time
    consuming to actually `fix
    <https://stackoverflow.com/a/51573205/1307905>`__ the tests.

0.15.45 (2018-07-26):
  - After adding failing test for ``YAML.load_all(Path())``, remove StopIteration 
    (PR provided by `Zachary Buhman <https://bitbucket.org/buhman/>`__,
    also reported by `Steven Hiscocks <https://bitbucket.org/sdhiscocks/>`__.

0.15.44 (2018-07-14):
  - Correct loading plain scalars consisting of numerals only and
    starting with `0`, when not explicitly specifying YAML version
    1.1. This also fixes the issue about dumping string `'019'` as
    plain scalars as reported by `Min RK
    <https://bitbucket.org/minrk/>`__, that prompted this chance.

0.15.43 (2018-07-12):
  - merge PR33: Python2.7 on Windows is narrow, but has no
    ``sysconfig.get_config_var('Py_UNICODE_SIZE')``. (merge provided by
    `Marcel Bargull <https://bitbucket.org/mbargull/>`__)
  - ``register_class()`` now returns class (proposed by
    `Mike Nerone <https://bitbucket.org/Manganeez/>`__}

0.15.42 (2018-07-01):
  - fix regression showing only on narrow Python 2.7 (py27mu) builds
    (with help from
    `Marcel Bargull <https://bitbucket.org/mbargull/>`__ and
    `Colm O'Connor <https://bitbucket.org/colmoconnorgithub/>`__).
  - run pre-commit ``tox`` on Python 2.7 wide and narrow, as well as
    3.4/3.5/3.6/3.7/pypy

0.15.41 (2018-06-27):
  - add detection of C-compile failure (investigation prompted by
    `StackOverlow <https://stackoverflow.com/a/51057399/1307905>`__ by
    `Emmanuel Blot <https://stackoverflow.com/users/8233409/emmanuel-blot>`__),
    which was removed while no longer dependent on ``libyaml``, C-extensions
    compilation still needs a compiler though.

0.15.40 (2018-06-18):
  - added links to landing places as suggested in issue 190 by
    `KostisA <https://bitbucket.org/ankostis/>`__
  - fixes issue #201: decoding unicode escaped tags on Python2, reported
    by `Dan Abolafia <https://bitbucket.org/danabo/>`__

0.15.39 (2018-06-17):
  - merge PR27 improving package startup time (and loading when regexp not
    actually used), provided by
    `Marcel Bargull <https://bitbucket.org/mbargull/>`__

0.15.38 (2018-06-13):
  - fix for losing precision when roundtripping floats by
    `Rolf Wojtech <https://bitbucket.org/asomov/>`__
  - fix for hardcoded dir separator not working for Windows by
    `Nuno André <https://bitbucket.org/nu_no/>`__
  - typo fix by `Andrey Somov <https://bitbucket.org/asomov/>`__

0.15.37 (2018-03-21):
  - again trying to create installable files for 187

0.15.36 (2018-02-07):
  - fix issue 187, incompatibility of C extension with 3.7 (reported by
    Daniel Blanchard)

0.15.35 (2017-12-03):
  - allow ``None`` as stream when specifying ``transform`` parameters to
    ``YAML.dump()``.
    This is useful if the transforming function doesn't return a meaningful value
    (inspired by `StackOverflow <https://stackoverflow.com/q/47614862/1307905>`__ by
    `rsaw <https://stackoverflow.com/users/406281/rsaw>`__).

0.15.34 (2017-09-17):
  - fix for issue 157: CDumper not dumping floats (reported by Jan Smitka)

0.15.33 (2017-08-31):
  - support for "undefined" round-tripping tagged scalar objects (in addition to
    tagged mapping object). Inspired by a use case presented by Matthew Patton
    on `StackOverflow <https://stackoverflow.com/a/45967047/1307905>`__.
  - fix issue 148: replace cryptic error message when using !!timestamp with an
    incorrectly formatted or non- scalar. Reported by FichteFoll.

0.15.32 (2017-08-21):
  - allow setting ``yaml.default_flow_style = None`` (default: ``False``) for
    for ``typ='rt'``.
  - fix for issue 149: multiplications on ``ScalarFloat`` now return ``float``
    (reported by jan.brezina@tul.cz)

0.15.31 (2017-08-15):
  - fix Comment dumping

0.15.30 (2017-08-14):
  - fix for issue with "compact JSON" not parsing: ``{"in":{},"out":{}}``
    (reported on `StackOverflow <https://stackoverflow.com/q/45681626/1307905>`__ by
    `mjalkio <https://stackoverflow.com/users/5130525/mjalkio>`_

0.15.29 (2017-08-14):
  - fix issue #51: different indents for mappings and sequences (reported by
    Alex Harvey)
  - fix for flow sequence/mapping as element/value of block sequence with
    sequence-indent minus dash-offset not equal two.

0.15.28 (2017-08-13):
  - fix issue #61: merge of merge cannot be __repr__-ed (reported by Tal Liron)

0.15.27 (2017-08-13):
  - fix issue 62, YAML 1.2 allows ``?`` and ``:`` in plain scalars if non-ambigious
    (reported by nowox)
  - fix lists within lists which would make comments disappear

0.15.26 (2017-08-10):
  - fix for disappearing comment after empty flow sequence (reported by
    oit-tzhimmash)

0.15.25 (2017-08-09):
  - fix for problem with dumping (unloaded) floats (reported by eyenseo)

0.15.24 (2017-08-09):
  - added ScalarFloat which supports roundtripping of 23.1, 23.100,
    42.00E+56, 0.0, -0.0 etc. while keeping the format. Underscores in mantissas
    are not preserved/supported (yet, is anybody using that?).
  - (finally) fixed longstanding issue 23 (reported by `Antony Sottile
    <https://bitbucket.org/asottile/>`__), now handling comment between block
    mapping key and value correctly
  - warn on YAML 1.1 float input that is incorrect (triggered by invalid YAML
    provided by Cecil Curry)
  - allow setting of boolean representation (`false`, `true`) by using:
    ``yaml.boolean_representation = [u'False', u'True']``

0.15.23 (2017-08-01):
  - fix for round_tripping integers on 2.7.X > sys.maxint (reported by ccatterina)

0.15.22 (2017-07-28):
  - fix for round_tripping singe excl. mark tags doubling (reported and fix by Jan Brezina)

0.15.21 (2017-07-25):
  - fix for writing unicode in new API, (reported on
    `StackOverflow <https://stackoverflow.com/a/45281922/1307905>`__

0.15.20 (2017-07-23):
  - wheels for windows including C extensions

0.15.19 (2017-07-13):
  - added object constructor for rt, decorator ``yaml_object`` to replace YAMLObject.
  - fix for problem using load_all with Path() instance
  - fix for load_all in combination with zero indent block style literal
    (``pure=True`` only!)

0.15.18 (2017-07-04):
  - missing ``pure`` attribute on ``YAML`` useful for implementing `!include` tag
    constructor for `including YAML files in a YAML file
    <https://stackoverflow.com/a/44913652/1307905>`__
  - some documentation improvements
  - trigger of doc build on new revision

0.15.17 (2017-07-03):
  - support for Unicode supplementary Plane **output**
    (input was already supported, triggered by
    `this <https://stackoverflow.com/a/44875714/1307905>`__ Stack Overflow Q&A)

0.15.16 (2017-07-01):
  - minor typing issues (reported and fix provided by
    `Manvendra Singh <https://bitbucket.org/manu-chroma/>`__
  - small doc improvements

0.15.15 (2017-06-27):
  - fix for issue 135, typ='safe' not dumping in Python 2.7
    (reported by Andrzej Ostrowski <https://bitbucket.org/aostr123/>`__)

0.15.14 (2017-06-25):
  - fix for issue 133, in setup.py: change ModuleNotFoundError to
    ImportError (reported and fix by
    `Asley Drake  <https://github.com/aldraco>`__)

0.15.13 (2017-06-24):
  - suppress duplicate key warning on mappings with merge keys (reported by
    Cameron Sweeney)

0.15.12 (2017-06-24):
  - remove fatal dependency of setup.py on wheel package (reported by
    Cameron Sweeney)

0.15.11 (2017-06-24):
  - fix for issue 130, regression in nested merge keys (reported by
    `David Fee <https://bitbucket.org/dfee/>`__)

0.15.10 (2017-06-23):
  - top level PreservedScalarString not indented if not explicitly asked to
  - remove Makefile (not very useful anyway)
  - some mypy additions

0.15.9 (2017-06-16):
  - fix for issue 127: tagged scalars were always quoted and seperated
    by a newline when in a block sequence (reported and largely fixed by
    `Tommy Wang <https://bitbucket.org/twang817/>`__)

0.15.8 (2017-06-15):
  - allow plug-in install via ``install ruamel.yaml[jinja2]``

0.15.7 (2017-06-14):
  - add plug-in mechanism for load/dump pre resp. post-processing

0.15.6 (2017-06-10):
  - a set() with duplicate elements now throws error in rt loading
  - support for toplevel column zero literal/folded scalar in explicit documents

0.15.5 (2017-06-08):
  - repeat `load()` on a single `YAML()` instance would fail.

0.15.4 (2017-06-08):
  - `transform` parameter on dump that expects a function taking a
    string and returning a string. This allows transformation of the output
    before it is written to stream. This forces creation of the complete output in memory!
  - some updates to the docs

0.15.3 (2017-06-07):
  - No longer try to compile C extensions on Windows. Compilation can be forced by setting
    the environment variable `RUAMEL_FORCE_EXT_BUILD` to some value
    before starting the `pip install`.

0.15.2 (2017-06-07):
  - update to conform to mypy 0.511: mypy --strict

0.15.1 (2017-06-07):
  - `duplicate keys  <http://yaml.readthedocs.io/en/latest/api.html#duplicate-keys>`__
    in mappings generate an error (in the old API this change generates a warning until 0.16)
  - dependecy on ruamel.ordereddict for 2.7 now via extras_require

0.15.0 (2017-06-04):
  - it is now allowed to pass in a ``pathlib.Path`` as "stream" parameter to all
    load/dump functions
  - passing in a non-supported object (e.g. a string) as "stream" will result in a
    much more meaningful YAMLStreamError.
  - assigning a normal string value to an existing CommentedMap key or CommentedSeq
    element will result in a value cast to the previous value's type if possible.
  - added ``YAML`` class for new API

0.14.12 (2017-05-14):
  - fix for issue 119, deepcopy not returning subclasses (reported and PR by
    Constantine Evans <cevans@evanslabs.org>)

0.14.11 (2017-05-01):
  - fix for issue 103 allowing implicit documents after document end marker line (``...``)
    in YAML 1.2

0.14.10 (2017-04-26):
  - fix problem with emitting using cyaml

0.14.9 (2017-04-22):
  - remove dependency on ``typing`` while still supporting ``mypy``
    (http://stackoverflow.com/a/43516781/1307905)
  - fix unclarity in doc that stated 2.6 is supported (reported by feetdust)

0.14.8 (2017-04-19):
  - fix Text not available on 3.5.0 and 3.5.1, now proactively setting version guards
    on all files (reported by `João Paulo Magalhães <https://bitbucket.org/jpmag/>`__)

0.14.7 (2017-04-18):
  - round trip of integers (decimal, octal, hex, binary) now preserve
    leading zero(s) padding and underscores. Underscores are presumed
    to be at regular distances (i.e. ``0o12_345_67`` dumps back as
    ``0o1_23_45_67`` as the space from the last digit to the
    underscore before that is the determining factor).

0.14.6 (2017-04-14):
  - binary, octal and hex integers are now preserved by default. This
    was a known deficiency. Working on this was prompted by the issue report (112)
    from devnoname120, as well as the additional experience with `.replace()`
    on `scalarstring` classes.
  - fix issues 114: cannot install on Buildozer (reported by mixmastamyk).
    Setting env. var ``RUAMEL_NO_PIP_INSTALL_CHECK`` will suppress ``pip``-check.

0.14.5 (2017-04-04):
  - fix issue 109: None not dumping correctly at top level (reported by Andrea Censi)
  - fix issue 110: .replace on Preserved/DoubleQuoted/SingleQuoted ScalarString
    would give back "normal" string (reported by sandres23)

0.14.4 (2017-03-31):
  - fix readme

0.14.3 (2017-03-31):
  - fix for 0o52 not being a string in YAML 1.1 (reported on
    `StackOverflow Q&A 43138503 <http://stackoverflow.com/a/43138503/1307905>`__ by
    `Frank D <http://stackoverflow.com/users/7796630/frank-d>`__)

0.14.2 (2017-03-23):
  - fix for old default pip on Ubuntu 14.04 (reported by Sébastien Maccagnoni-Munch)

0.14.1 (2017-03-22):
  - fix Text not available on 3.5.0 and 3.5.1 (reported by Charles Bouchard-Légaré)

0.14.0 (2017-03-21):
  - updates for mypy --strict
  - preparation for moving away from inheritance in Loader and Dumper, calls from e.g.
    the Representer to the Serializer.serialize() are now done via the attribute
    .serializer.serialize(). Usage of .serialize() outside of Serializer will be
    deprecated soon
  - some extra tests on main.py functions

----

For older changes see the file
`CHANGES <https://bitbucket.org/ruamel/yaml/src/default/CHANGES>`_


